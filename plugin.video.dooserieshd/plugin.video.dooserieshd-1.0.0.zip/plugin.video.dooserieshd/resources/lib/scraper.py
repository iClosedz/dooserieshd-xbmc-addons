#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#     Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import urllib2,urllib,re
from BeautifulSoup import BeautifulSoup

#ขอความกรุณาอย่าเข้าลิงค์เอง นอกจากจะกำหนด user-agent ในการเข้าก่อนเพื่อที่จะได้ใช้กันนานๆนะครับ ขอบคุณครับ

MAIN_URL = 'http://series9.servicedooeii.com/serie9handler.ashx'
POSTER_URL = 'http://www.series9-admin.com/poster/'
NEXT_IMG = 'http://static.hd-trailers.net/images/mobile/next.png'
PREV_IMG = 'http://static.hd-trailers.net/images/mobile/prev.png'
USER_AGENT = 'Series 9 HD/2.0.1 CFNetwork/609 Darwin/13.0.0'

class NetworkError(Exception):
	pass

def get_latest(page, stype):
	url = MAIN_URL + '?type=serie&pid=%d&ps=20' % int(page-1)
	return _get_names(url)

def get_orderby(page, stype):
	url = MAIN_URL + '?type=serie&pid=%d&ps=20&orderby=name' % int(page-1)
	return _get_names(url)

def get_episodes(episode_id):
	url = MAIN_URL + '?type=serielink&ps=100&id=%d' % int(episode_id)
    	tree, html = __get_tree(url)
	pattern = re.compile("\<Link\>(?P<link>[^\<]*)\<\/Link\>\s*")
	total = re.finditer(pattern,html)
	bufferr = []
	for i in total:
		bufferr.append({'source' : i.group('link')})
	episodes = [{
		'title': __decodefunction(item.seriename.string),
		'part': item.partnumber.string,
		'date': item.lastupdated.string
	} for item in tree.findAll('item')]
	count = 0
	for i in episodes:
		i.update(bufferr[count])
		count+=1
	log('_get_episodes got %d item' % len(episodes))
	return episodes

def _get_names(url):
	tree, html = __get_tree(url)
	
	names = []
	for item in tree.findAll('item'):
		status = item.status.string
		statusname = ''	
		if status == '0':
			statusname = '[Soon]'
		elif status == '1':
			statusname = '[Airing]'
		elif status == '2':
			statusname = '[Completed]'
		names.extend([{
			'id': item.id.string,
			'title': __decodefunction(item.entitle.string),
			'thumb': POSTER_URL + __decodefunction(item.picturename.string),
			'genre': __decodefunction(item.type.string),
			'year': int(item.dateshowtime.string),
			'numberofep': int(item.numberofpart.string),
			'director': __decodefunction(item.director.string),
			'plot': __decodefunction(item.abstract.string),
			'prodcom': __decodefunction(item.productioncompany.string),
			'studio': __decodefunction(item.stationonair.string),
			'writer': __decodefunction(item.written.string),
			'statusname': statusname,
			'trailer': __decodefunction(item.trailer.string),
			'lastupdated': __decodefunction(item.lastupdated.string)
		}])
	'''
#	status = int(item.status.string)
	statusname = ''	
#	if status == 0:
#		statusname = '[Soon]'
#	elif status == 1:
#		statusname = '[Air]'
#	elif status == 2:
#		statusname = '[End]'
	names = [{
		'id': item.id.string,
		'title': __decodefunction(item.entitle.string),
		'thumb': POSTER_URL + __decodefunction(item.picturename.string),
		'genre': __decodefunction(item.type.string),
		'year': int(item.dateshowtime.string),
		'numberofep': int(item.numberofpart.string),
		'director': __decodefunction(item.director.string),
		'plot': __decodefunction(item.abstract.string),
		'prodcom': __decodefunction(item.productioncompany.string),
		'studio': __decodefunction(item.stationonair.string),
		'writer': __decodefunction(item.written.string),
		'statusname': statusname,
		'trailer': __decodefunction(item.trailer.string),
		'lastupdated': __decodefunction(item.lastupdated.string)
	}for item in tree.findAll('item')]
	'''
	log('_get_names got %d item' % len(names))
	return names

def __get_tree(url):
	log('__get_tree opening url: %s' % url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree got %d bytes' % len(html))
	tree = BeautifulSoup(html, convertEntities=BeautifulSoup.XML_ENTITIES)
	return tree, html

def __decodefunction(text):
    try:
        text = unicode(text, 'utf-8')
    except TypeError:
        return text

def log(msg):
	print(u'%s scraper: %s' % (USER_AGENT, msg))
