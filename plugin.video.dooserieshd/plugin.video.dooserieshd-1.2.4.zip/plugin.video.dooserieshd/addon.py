#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#     Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

from xbmcswift2 import Plugin, xbmcgui, xbmcaddon
from resources.lib import scraper

STRINGS = {
	'page': 30001,
	'download': 30002,
	'already_downloaded': 30003,
	'download_in_progress': 30004,
	'us_series': 40000,
	'kr_series': 40001,
	'jp_series': 40002,
	'anime': 40003,
	'th_series': 40004,
	'movies': 40005,
	'ch_3': 40010,
	'ch_5': 40011,
	'ch_7': 40012,
	'ch_9': 40013,
	'ch_etc': 40014,
	'latest': 50000,
	'orderby': 50001,
	'newupdate': 50002,
	'search': 50003,
	'no_download_path': 70000,
	'want_set_now': 70001,
	'network_error': 80000
}

plugin = Plugin()

@plugin.route('/')
def index():
	items = [
		{'label': _('us_series'),
		'path': plugin.url_for('show_series', stype='us').encode('utf-8')},
		{'label': _('kr_series'),
		'path': plugin.url_for('show_series', stype='kr').encode('utf-8')},
		{'label': _('jp_series'),
		'path': plugin.url_for('show_series', stype='jp').encode('utf-8')},
		{'label': _('anime'),
		'path': plugin.url_for('show_series', stype='an').encode('utf-8')},
		{'label': _('th_series'),
		'path': plugin.url_for('show_series', stype='th').encode('utf-8')},
		{'label': _('movies'),
		'path': plugin.url_for('show_series', stype='mo').encode('utf-8')}
	]
	return plugin.finish(items)

@plugin.route('/series/<stype>/')
def show_series(stype):
	if stype == 'mo':
		items = [
			{'label': _('latest'),
				'path': plugin.url_for('show_names', stype=stype, soption='latest').encode('utf-8')},
			{'label': _('orderby'),
				'path': plugin.url_for('show_names', stype=stype, soption='orderby').encode('utf-8')},
			{'label': _('search'),
				'path': plugin.url_for('show_search', stype=stype, soption='search').encode('utf-8')}
		]
	else:
		items = [
			{'label': _('latest'),
				'path': plugin.url_for('show_names', stype=stype, soption='latest').encode('utf-8')},
			{'label': _('orderby'),
				'path': plugin.url_for('show_names', stype=stype, soption='orderby').encode('utf-8')},
			{'label': _('newupdate'),
				'path': plugin.url_for('show_new_episodes', stype=stype, soption='newupdate').encode('utf-8')},
			{'label': _('search'),
				'path': plugin.url_for('show_search', stype=stype, soption='search').encode('utf-8')}
		]
	return plugin.finish(items)

@plugin.route('/series/<stype>/<soption>/s/')
def show_search(stype, soption):
	search_string = plugin.keyboard(heading=_('search'))
	if search_string:
		url = plugin.url_for(
			'search_result',
			stype = stype,
			soption = soption,
			search_string = search_string
		).encode('utf-8')
		plugin.redirect(url)

@plugin.route('/series/<stype>/<soption>/s/<search_string>/')
def search_result(stype, soption, search_string):
	names = scraper.get_serch_result(stype, search_string)
	return add_search_result(stype, soption, names)

def add_search_result(stype, soption, names):
	if stype == 'mo':
		endp = 'show_movies'
	else:
		endp = 'show_episodes'
	items = [{
		'label': name['title']+' '+name['statusname'], #+' Update ('+name['lastupdated']+')',
		'thumbnail': name['thumb'],
		'info': {
			'count': i,
			'genre': name['genre'],
			'year': name['year'],
			'episode': name['numberofep'],
			'director': name['director'],
			'plot': name['plot'],
			'plotoutline': name['prodcom'],
			'title': name['title'],
			'studio': name['studio'],
			'writer': name['writer'],
			'tvshowtitle': name['title'],
			'premiered': name['year'],
			'status': name['statusname'],
			'trailer': name['trailer']
		},
		'path': plugin.url_for(
			endpoint=endp,
			stype=stype,
			soption=soption,
			name_id=name['id']
		).encode('utf-8')
	} for i, name in enumerate(names)]
	plugin.set_content('tvshows')
	return plugin.finish(items)

@plugin.route('/series/<stype>/<soption>')
def show_names(stype, soption):
	page = 1
	if soption == 'latest':
		page = int(plugin.request.args.get('page', ['1'])[0])
		names = scraper.get_latest(page, stype)
	elif soption == 'orderby':
		page = int(plugin.request.args.get('page', ['1'])[0])
		names = scraper.get_orderby(page, stype)
	if stype == 'mo':
		endp = 'show_movies'
	else:
		endp = 'show_episodes'
	items = []
	
	if page > 1:
		previous_page = str(page - 1)
		items.append({
			'label': '<< %s %s <<' % (_('page'), previous_page),
			'thumbnail': scraper.PREV_IMG,
			'path': plugin.url_for(
				endpoint='show_names',
				stype=stype,
				soption=soption,
				page=previous_page,
				update='true'
			).encode('utf-8')
		})
	next_page = str(page + 1)
	items.append({
		'label': '>> %s %s >>' % (_('page'), next_page),
		'thumbnail': scraper.NEXT_IMG,
		'path': plugin.url_for(
			endpoint='show_names',
			stype=stype,
			soption=soption,
			page=next_page,
			update='true'
		).encode('utf-8')
	})
	
	items.extend([{
		'label': name['title'], #+' '+name['statusname'], #+' Update ('+name['lastupdated']+')',
		'thumbnail': name['thumb'],
		'info': {
			'count': i,
			'genre': name['genre'],
			'year': name['year'],
			'episode': name['numberofep'],
			'director': name['director'],
			'plot': name['plot'],
			'plotoutline': name['prodcom'],
			'title': name['title'],
			'studio': name['studio'],
			'writer': name['writer'],
			'tvshowtitle': name['title'],
			'premiered': name['year'],
			'status': name['statusname'],
			'trailer': name['trailer']
		},
		'path': plugin.url_for(
			endpoint=endp,
			stype=stype,
			soption=soption,
			name_id=name['id']
		).encode('utf-8')
	} for i, name in enumerate(names)])
	plugin.set_content('tvshows')
	return plugin.finish(items, update_listing=True)

@plugin.route('/series/<stype>/<soption>/mname/<name_id>/')
def show_movies(stype, soption, name_id):
	movies = scraper.get_movies(name_id, stype)
	downloads = plugin.get_storage('downloads')
	items = []
	for i, movie in enumerate(movies):
		url = movie['source']
		thumb = movie['thumb']
		title = movie['title']
		if url in downloads:
			import xbmcvfs  # FIXME: import from swift after fixed there
			if xbmcvfs.exists(downloads[url]):
				title = '%s - %s' % (title, _('already_downloaded'))
			#else:
				#download_status = _('download_in_progress')
		items.extend([{
			'label': title,
			'thumbnail': thumb,
			'info': {
				'count': i,
			},
			'context_menu': [
				(_('download'), 'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='download_video',
				stype=stype,
				soption=soption,
				url=movie['source']
			).encode('utf-8'))
                	],
              		'is_playable': True,
			'path': plugin.url_for(
				endpoint='play_video',
				stype=stype,
				soption=soption,
				url=movie['source']
			).encode('utf-8')
		}])
	return plugin.finish(items)

@plugin.route('/series/<stype>/<soption>/newepisodes/', name='show_new_episodes', options={'name_id': '0'})
@plugin.route('/series/<stype>/<soption>/name/<name_id>/')
def show_episodes(stype, soption, name_id):
	if soption == 'newupdate':
		episodes = scraper.get_new_episodes(stype)	
	else:	
		episodes = scraper.get_episodes(name_id, stype)
	downloads = plugin.get_storage('downloads')
	
	items = []
	for i, episode in enumerate(episodes):
		url = episode['source']
		if soption == 'newupdate':
			thumb = episode['thumb']
			title = episode['title'] + ' EP ' + episode['part'] + ' ' + episode['status']
		else:
			title = 'EP ' + episode['part'] + ' (' + episode['date'] + ')'
			thumb = ''
		if url in downloads:
			import xbmcvfs  # FIXME: import from swift after fixed there
			if xbmcvfs.exists(downloads[url]):
				title = '%s - %s' % (title, _('already_downloaded'))
			#else:
				#download_status = _('download_in_progress')
		items.extend([{
			'label': title,
			'thumbnail': thumb,
			'info': {
				'count': i,
			},
			'context_menu': [
				(_('download'), 'XBMC.RunPlugin(%s)' % plugin.url_for(
				endpoint='download_video',
				stype=stype,
				soption=soption,
				url=episode['source']
			).encode('utf-8'))
                	],
              		'is_playable': True,
			'path': plugin.url_for(
				endpoint='play_video',
				stype=stype,
				soption=soption,
				url=episode['source']
			).encode('utf-8')
		}])
	return plugin.finish(items)

@plugin.route('/series/<stype>/<soption>/download/<url>/')
def download_video(stype, soption, url):
	import SimpleDownloader
	sd = SimpleDownloader.SimpleDownloader()
	playable_url = url
	download_path = plugin.get_setting('download_path')
	while not download_path:
		try_again = xbmcgui.Dialog().yesno(
			_('no_download_path'),
			_('want_set_now')
		)
		if not try_again:
			return
		plugin.open_settings()
		download_path = plugin.get_setting('download_path')
	filename = playable_url.split('?')[0].split('/')[-1]
	params = {
		'url': playable_url,
		'download_path': download_path
	}
	sd.download(filename, params)
	downloads = plugin.get_storage('downloads')
	downloads[url] = xbmc.translatePath(download_path + filename)
	downloads.sync()

@plugin.route('/series/<stype>/<soption>/play/<url>/')
def play_video(stype, soption, url):
	downloads = plugin.get_storage('downloads')
	if url in downloads:
		local_file = downloads[url]
		# download was already started
		import xbmcvfs  # FIXME: import from swift after fixed there
		if xbmcvfs.exists(local_file):
			# download was also finished
			log('Using local file: %s' % local_file)
			return plugin.set_resolved_url(local_file)
	playable_url = url
	log('Using URL: %s' % playable_url)
	return plugin.set_resolved_url(playable_url)

def _(string_id):
	if string_id in STRINGS:
		return plugin.get_string(STRINGS[string_id])
	else:
		plugin.log.warning('String is missing: %s' % string_id)
		return string_id

def log(text):
	plugin.log.info(text)

if __name__ == '__main__':
	plugin.run()
