#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#     Copyright (C) 2013 iClosedz (iClosedz.blogspot.com)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import urllib2,urllib,re
from BeautifulSoup import BeautifulSoup

NEXT_IMG = 'http://static.hd-trailers.net/images/mobile/next.png'
PREV_IMG = 'http://static.hd-trailers.net/images/mobile/prev.png'
usefull = {'stype': '', 'surl': '', 'poster': '', 'uagent': ''}

def get_latest(page, stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=serie&pid=%d&ps=20' % int(page-1)
	return _get_names(url)

def get_orderby(page, stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=serie&pid=%d&ps=20&orderby=name' % int(page-1)
	return _get_names(url)

def get_serch_result(stype, search_string):
	usefull = __get_usefull(stype)
	params = {'keyword': search_string}
	url = usefull['surl'] + '?type=serie&pid=0&ps=1000&%s' % urllib.urlencode(params)
	return _get_names(url)

def get_movies(name_id, stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=seriedetail&id=%d' % int(name_id)
	tree, html = __get_tree(url)
	getmovies = {'title': '', 'thumb': '', 'source1': '', 'source2': ''}
	for item in tree.findAll('item'):         
		getmovies['title'] = item.entitle.string
		getmovies['thumb'] = usefull['poster'] + item.picturename.string
		getmovies['source1'] = item.thailink.string
		getmovies['source2'] = item.subthailink.string
	movies = []
	for i in range(0, 2):
		if i == 0:
			m_title = getmovies['title'] + ' [THAI]'
			sc = 'source1'
		else:
			m_title = getmovies['title'] + ' [SUBTHAI]'
			sc = 'source2'
		movies.append({
			'title': m_title,
			'thumb': getmovies['thumb'],
			'source': getmovies[sc]
		})
	return movies

def get_episodes(name_id, stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=serielink&ps=100&id=%d' % int(name_id)
	tree, html = __get_tree(url)
	pattern = re.compile("\<Link\>(?P<link>[^\<]*)\<\/Link\>\s*")
	total = re.finditer(pattern,html)
	bufferr = []
	for i in total:
		bufferr.append({'source' : i.group('link')})
	episodes = []
	for item in tree.findAll('item'):         
		episodes.append({
			'title': item.seriename.string,
			'part': item.partnumber.string,
			'date': item.lastupdated.string
		})
	count = 0
	for i in episodes:
		i.update(bufferr[count])
		count+=1
	log('_get_episodes got %d item' % len(episodes))
	return episodes

def get_new_episodes(stype):
	usefull = __get_usefull(stype)
	url = usefull['surl'] + '?type=serienews&ps=20&pid=0&device=dc9ee5e129b9633f875cec2dde8b9eaee7de9c443afd4091ab77b4dbd97e7669&version=ipad'
	tree, html = __get_tree(url)
	pattern = re.compile("\<link\>(?P<link>[^\<]*)\<\/link\>\s*")
	total = re.finditer(pattern,html)
	bufferr = []
	for i in total:
		bufferr.append({'source' : i.group('link')}) 
	episodes = []
	
	for item in tree.findAll('item'):
		if item.status.string == '0':
			item.status.string = '[Soon]'
		elif item.status.string == '1':
			item.status.string = '[Airing]'
		elif item.status.string == '2':
			item.status.string = '[Completed]'     
		episodes.append({
			'title': item.seriename.string,
			'part': item.partname.string,
			'thumb': usefull['poster'] + item.picturename.string,
			'date': item.lastupdated.string,
			'status': item.status.string
		})
	count = 0
	for i in episodes:
		i.update(bufferr[count])
		count+=1
	log('_get_new_episodes got %d item' % len(episodes))
	return episodes

def _get_names(url):
	tree, html = __get_tree(url)
	names = []
	for item in tree.findAll('item'):
		if item.status.string == '0':
			item.status.string = '[Soon]'
		elif item.status.string == '1':
			item.status.string = '[Airing]'
		elif item.status.string == '2':
			item.status.string = '[Completed]'
		if (item.dateshowtime.string != None) and (len(item.dateshowtime.string) > 4):
			item.dateshowtime.string = item.dateshowtime.string[-4:]
		names.append({
			'id': item.id.string,
			'title': item.entitle.string,
			'thumb': usefull['poster'] + item.picturename.string,
			'genre': item.type.string,
			'year': item.dateshowtime.string,
			'numberofep': item.numberofpart.string,
			'director': item.director.string,
			'plot': item.abstract.string,
			'prodcom': item.productioncompany.string,
			'studio': item.stationonair.string,
			'writer': item.written.string,
			'statusname': item.status.string,
			'trailer': item.trailer.string,
			'lastupdated': item.lastupdated.string
		})
	log('_get_names got %d item' % len(names))
	return names

def __get_tree(url):
	log('__get_tree opening url: %s' % url)
	req = urllib2.Request(url)
	req.add_header('User-Agent', usefull['uagent'])
	try:
		html = urllib2.urlopen(req).read()
	except urllib2.HTTPError, error:
		raise NetworkError('HTTPError: %s' % error)
	log('__get_tree got %d bytes' % len(html))
	tree = BeautifulSoup(html, convertEntities=BeautifulSoup.XML_ENTITIES)
	return tree, html

def __get_usefull(stype):
	if stype == 'us':
		usefull['stype'] = 'us'
		usefull['surl'] = 'http://series9.servicedooeii.com/serie9handler.ashx'
		usefull['poster'] = 'http://www.series9-admin.com/poster/'
		usefull['uagent'] = 'Series 9 HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'kr':
		usefull['stype'] = 'kr'
		usefull['surl'] = 'http://series8.servicedooeii.com/Serie8Handler.ashx'
		usefull['poster'] = 'http://www.series8-admin.com/poster/'
		usefull['uagent'] = 'Series 8 HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'jp':
		usefull['stype'] = 'jp'
		usefull['surl'] = 'http://series7.servicedooeii.com/serie7/service.ashx'
		usefull['poster'] = 'http://www.series7-admin.com/poster/'
		usefull['uagent'] = 'Series 7 HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'an':
		usefull['stype'] = 'an'
		usefull['surl'] = 'http://anime.servicedooeii.com/anime/service.ashx'
		usefull['poster'] = 'http://www.animefc-admin.com/poster/'
		usefull['uagent'] = 'AnimeFC HD/2.0.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'th':
		usefull['stype'] = 'th'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/thaidrama.ashx'
		usefull['poster'] = 'http://www.series6-admin.com/poster/'
		usefull['uagent'] = 'Series 6 HD/2.1 CFNetwork/609 Darwin/13.0.0'
	elif stype == 'mo':
		usefull['stype'] = 'mo'
		usefull['surl'] = 'http://seriesseries.servicedooeii.com/moviefc.ashx'
		usefull['poster'] = 'http://www.moviefc-admin.com/poster/'
		usefull['uagent'] = 'MovieFC HD/1.0 CFNetwork/609 Darwin/13.0.0'
	return usefull

def log(msg):
	print(u'%s scraper: %s' % (usefull['uagent'], msg))
